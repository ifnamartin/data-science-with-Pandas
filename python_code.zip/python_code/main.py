import pandas as pd
from pandas import json_normalize
from datetime import datetime
import data_filtering as ff
import create_aux_dbs as aux
import kpi_calculation as kpi
import loading_and_dumping as ld
import group_by as gb

def main():

    # Paso 1: Cargamos los Datos
    path = "C:/Users/ignac/OneDrive/Escritorio/IGNACIO/Entrevista Delectatech/"    #Cambiar la localización del archivo en caso de ser necesario
    res_df = pd.read_json(path + "data/restaurant_data.json")
    com_df = pd.read_json(path + "data/comments.json")

    # Paso 2: Filtrar Establecimientos
    restaurants_df = ff.filter_restaurants(res_df)
    selected_restaurants = restaurants_df['_id']
    comments_df = ff.filter_comments(com_df,selected_restaurants)
    print('Los datos han sido filtrados por ciudad e intervalo \n')

    # Paso 3: Crear bases de datos auxiliares para facilitar los cálculos de KPI
    bymonth_df = aux.create_aux_1(restaurants_df)
    timetables_df = aux.create_aux_2(restaurants_df)
    rush_hours_df = aux.create_aux_3(timetables_df,bymonth_df)
    wine_rep_df = aux.create_aux_4(comments_df)
    print('Las bases de datos auxiliares han sido creadas \n')

    # Paso 4: Calcular los KPIs pedidos    
    avg_kpi = kpi.avg_kpi(bymonth_df)
    sum_kpi = kpi.sum_kpi(bymonth_df)
    open_days = kpi.open_days(timetables_df)
    occ_rates = kpi.occupation_rates(rush_hours_df)
    wine_repetitions = kpi.wine_reps(wine_rep_df)
    kpi_result_table = kpi.result_table(restaurants_df,avg_kpi,sum_kpi,open_days,occ_rates,wine_repetitions)
    print('Los KPIs requeridos han sido calculados \n')
    
    # Paso 5: Crear dump de databases auxiliares y de resultados
    ld.save_to_dump(restaurants_df,'restaurants_filtered',path)
    ld.save_to_dump(comments_df,'comments_filtered',path)
    ld.save_to_dump(bymonth_df,'aux_database_1',path)
    ld.save_to_dump(timetables_df,'aux_database_2',path)
    ld.save_to_dump(rush_hours_df,'aux_database_3',path)
    ld.save_to_dump(wine_rep_df,'aux_database_4',path)
    ld.save_to_dump(kpi_result_table,'kpi_results',path)
    print('Las bases de datos auxiliares y de resultados han sido almacenadas como archivos csv en la carpeta database_dump \n')

    # Paso 6: Calcular KPIs Agrupados por Zona y Atributos
    postal_groups = gb.group_by_postal(kpi_result_table)
    open_groups = gb.group_by_open(kpi_result_table)
    wine_groups = gb.group_by_wine(kpi_result_table)
    print('Los restaurantes han sido divididos por grupos segun código postal, días de apertura y aparición de vino \n')

    # Paso 7: Cargamos los resultados obtenidos en Excel
    ld.save_to_xls(postal_groups, 'postalCodeGroup',path)
    ld.save_to_xls(open_groups, 'timetableGroup',path)
    ld.save_to_xls(wine_groups, 'wineRelevanceGroup',path)
    print('Los archivos xls con los resultados para los distintos grupos han sido creados en la carpeta grouped_results_excel')

    return kpi_result_table

if __name__ == "__main__":
    main()
