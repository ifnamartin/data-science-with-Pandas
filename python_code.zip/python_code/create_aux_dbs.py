import pandas as pd
from nltk.tokenize import word_tokenize
import nltk
from datetime import datetime


## CREAMOS UN DATAFRAME AUXILIAR CON LOS DATOS EXPANDIDOS POR MESES (DF_AUX_1) ##

def create_aux_1(restaurants_df):
    df_bymonth = restaurants_df.explode('stats',ignore_index=True)

    # Creamos una columna nueva por cada campo de stats que necesitaremos, de manera que obtenemos una tabla en que cada fila representa un restaurante y un mes y contiene todos los datos necesarios

    used_columns = ["intervalName", "popularity_rate", "satisfaction_rate", "sentiment_value", "global_rating_value", "density", "average_price", "total_comments", "total_reviews"]
    df_stats = pd.json_normalize(df_bymonth['stats'])[used_columns]
    df_stats['rush_hours_json'] = df_bymonth['stats'].apply(lambda x: x.get('rush_hours_json', None))
    df_bymonth = pd.concat([df_bymonth, df_stats], axis=1)
    df_bymonth['total_comments'] = df_bymonth['total_comments'].abs()
    df_bymonth['total_reviews'] = df_bymonth['total_reviews'].abs()
    df_bymonth.drop('stats', axis=1, inplace=True)
    df_bymonth.set_index(['_id','intervalName'], inplace=True)


    return df_bymonth


## CREAMOS UN DATAFRAME AUXILIAR QUE RECOJA LOS HORARIOS DE APERTURA DE UN RESTAURANTE POR DÍAS (DF_AUX_2) ##

def create_aux_2(restaurants_df):
    timetables_df = restaurants_df.explode('timetables',ignore_index=True)[['_id','name','timetables']]
    timetables_df = timetables_df.dropna(subset=['timetables'])
    timetables_df = timetables_df.reset_index(drop=True)
    # Creamos una columna con cada día de la semana, diciendo si abre en ese horario o no
    days_df = pd.json_normalize(timetables_df['timetables'])
    timetables_df = pd.concat([timetables_df,days_df], axis=1)
    timetables_df.set_index(['_id'], inplace=True)
    
    return timetables_df


## CREAMOS UN DATAFRAME AUXILIAR CON LOS DATOS PARA CADA MES DE LAS RUSH HOURS Y LOS HORARIOS DE APERTURA (DF_AUX_3) ##

def create_aux_3(timetables_df, df_bymonth):
    time_df = timetables_df.apply(process_row, axis=1, result_type='expand')
    time_df = time_df.groupby('_id').agg(group_times)
    time_df.columns = ['mon','tue','wed','thu','fri','sat','sun']
    df_rush_nona = df_bymonth[['rush_hours_json']].dropna()
    # Con el inner join ignoramos los restaurantes que no tienen información de ambas variables
    rush_hours_df = df_rush_nona.merge(time_df, left_index=True, right_index=True, how='inner')
    return rush_hours_df

# Función que devuelve una lista con, para cada día de la semana, tuplas de su horario de apertura asociado

def process_row(row):
    result_cols = []
    for i in ['mon','tue','wed','thu','fri','sat','sun']:
        if row[i] == 1:
            result_cols.append((datetime.strptime(row['time_ini'], "%H:%M").time(), datetime.strptime(row['time_end'], "%H:%M").time()))
        else:
            result_cols.append(None)
    return result_cols

#Función que agrupa las tuplas de tiempo de apertura y cierre para cada día y cada restaurante

def group_times(x):
    result = list(filter(None, x))
    if result == []:
        return None
    else:
        return result

## CREAMOS UN DATAFRAME AUXILIAR PARA CONTAR LAS APARICIONES DE VINO (DF_AUX_4) ## 

def create_aux_4(comments_df):
    result_df = comments_df
    result_df.set_index(['_id', 'intervalName'], inplace=True)
    result_df['wine_present'] = result_df['comment'].apply(has_wine)

    return result_df

# Función booleana auxiliar que devuelve 1 si un comentario contiene el concepto de 'vino' y 0 en otro caso
def has_wine(text):
    tokens = word_tokenize(text.lower())
    return int(any(token in {'wine', 'vino', 'vin', 'wein', 'vi'} for token in tokens))


