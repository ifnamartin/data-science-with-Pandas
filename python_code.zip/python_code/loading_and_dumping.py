import pandas as pd
import os
import xlsxwriter


def save_to_dump(pandas_df,name,path):
    folder_path = path + 'database_dump'
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
    
    csv_file_path = os.path.join(folder_path, name+'.csv')
    pandas_df.to_csv(csv_file_path, index=True)

def save_to_xls(result_dict, name,path):
    folder_path = path + 'grouped_result_excels'
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
    excel_file_path = os.path.join(folder_path, name+'.xls')
    
    with pd.ExcelWriter(excel_file_path, engine='xlsxwriter') as writer:
        for sheet_name, df in result_dict.items():
            df.to_excel(writer, sheet_name=str(sheet_name), index=True)

