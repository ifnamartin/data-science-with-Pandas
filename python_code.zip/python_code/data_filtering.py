import pandas as pd
from pandas import json_normalize

# Seleccionamos los restaurantes que están en Barcelona y abiertos para intervalo de junio, julio y agosto    

def filter_restaurants(restaurants_df):
    # Seleccionamos los restaurantes en Barcelona
    barcelona_df = restaurants_df[restaurants_df['city_name'] == 'Barcelona']
    barcelona_df = barcelona_df.dropna(subset=['stats'])
    barcelona_df = barcelona_df.rename(columns={'uidentifier': '_id'})
    barcelona_df['stats'] = barcelona_df['stats'].apply(filter_stats)

    # Filtramos las filas donde 'closedAt' y 'deletedAt' son NULL para todos los intervalos
    filtered_df = barcelona_df[
        (barcelona_df['stats'].apply(lambda x: list(map(summer_and_open, x)).count(True)==3)) #Aqui estamos aplicando la funcion auxiliar a todos los meses, y quedandonos con las filas(restaurantes) que están abiertos en los tres meses buscados
    ]
    return filtered_df

# Función auxiliar que elimina los datos de stats que no pertenecen al intervalo analizado
def filter_stats(stats_list):
    return [stat for stat in stats_list if stat['intervalName'] in ['2022-06', '2022-07', '2022-08']]

# Función auxiliar que para un item de la lista stats te diga si se trata de un mes abierto y dentro de ['2022-06', '2022-07', '2022-08'] o no
def summer_and_open(monthly_stats):
    summer = ['2022-06', '2022-07', '2022-08']
    if monthly_stats['intervalName'] in summer and monthly_stats['closedAt'] == None and monthly_stats['deletedAt'] == None:
        return True
    return False

# Seleccionamos los comentarios de ese mismo subgrupo de restaurantes y dentro de ese periodo
#Como el db comments no contiene información sobre la ciudad, para ahorrar cálculos innecesarios y optimizar el programa, tendremos que utilizar los datos de restaurants_data. Para ello utilizaremos la función de filtro ya diseñada antes.

def filter_comments(comments_df, selected_restaurants):
    selected_months = ["2022-08", "2022-07", "2022-06"]
    result_df = comments_df[(comments_df['restaurantUidentifier'].isin(selected_restaurants))&(comments_df['publicationYearMonth'].isin(selected_months)) & (comments_df['body'].notnull())]
    result_df = result_df[['restaurantUidentifier', 'publicationYearMonth', 'body']]
    result_df.columns = ['_id','intervalName','comment']

    return result_df
