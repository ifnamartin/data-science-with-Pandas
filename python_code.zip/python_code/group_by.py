import pandas as pd


# Función que devuelve un diccionario con las keys siendo cada código postal y los valores DataFrames con los kpi pedidos
def group_by_postal(result_df):
    df = result_df.copy()
    df = groups_new_kpi(df)
    grouped = df.groupby('postal_code')
    postal_groups = {group_name: group for group_name, group in grouped}
    
    return postal_groups

# Función que devuelve un diccionario con las keys siendo entre semana o fin de semana y los valores DataFrames con los kpi pedidos
def group_by_open(result_df):
    df = result_df.copy()
    open_groups = {'Weekdays': None, 'Weekends': None}
    df['Weekdays_group'] = (df['weekdayOpened'] > 2).astype(int)
    df['Weekends_group'] = (df['weekendOpened'] > 1).astype(int)
    open_groups['Weekdays'] = groups_new_kpi(df[df['Weekdays_group'] == 1])
    open_groups['Weekends'] = groups_new_kpi(df[df['Weekends_group'] == 1])

    return open_groups

# Función que devuelve un diccionario con la key siendo el grupo de restaurantes que contiene vino y los valores DataFrames con los kpi pedidos    
def group_by_wine(result_df):
    df = result_df.copy()
    wine_groups = {'ContainsWine':None}
    wine_groups['ContainsWine'] = groups_new_kpi(df[df['totalWineRepetitions'] > 0])

    return wine_groups

# Función auxiliar para calcular la nueva variable suma de reviews, comments y vino
def groups_new_kpi(result_df):
    df = result_df.copy()
    df['comments_and_wine'] = df[['total_reviews_sum', 'total_comments_sum', 'totalWineRepetitions']].sum(axis=1)
    df = df.drop(['weekdayOpened','weekendOpened','total_reviews_sum', 'total_comments_sum', 'totalWineRepetitions'], axis=1)

    return df


    
