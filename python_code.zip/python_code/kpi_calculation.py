import pandas as pd
from datetime import datetime

## CÁLCULO DE RESULTADOS 1: PROMEDIOS DE DISTINTOS INDICADORES ##

def avg_kpi(df_bymonth):
    kpi_avg_params = ["popularity_rate", "satisfaction_rate", "sentiment_value", "global_rating_value", "density", "average_price"]
    kpi_avg_cols = [kpi + "_average" for kpi in kpi_avg_params]
    kpi_avg_results = df_bymonth[kpi_avg_params].groupby('_id').mean()
    kpi_avg_results.columns = kpi_avg_cols
    
    return kpi_avg_results


## CÁLCULO DE RESULTADOS 2: SUMATORIO DE REVIEWS Y COMMENTS ##

def sum_kpi(df_bymonth):
    kpi_sum_params = ["total_comments","total_reviews"]
    kpi_sum_cols = [kpi + "_sum" for kpi in kpi_sum_params]
    kpi_sum_results = df_bymonth[kpi_sum_params].groupby('_id').sum()
    kpi_sum_results.columns = kpi_sum_cols
    
    return kpi_sum_results


## CÁLCULO DE RESULTADOS 3: DÍAS DE LA SEMANA EN QUE UN ESTABLECIMIENTO ABRE, SEPARADO POR ENTRE SEMANA Y FIN DE SEMANA ##

def open_days(timetables_df):
    weekdays = ['mon','tue','wed','thu']
    weekend = ['fri','sat','sun']
    days_result = timetables_df.groupby('_id')[weekdays+weekend].sum()
    days_result['weekdayOpened'] = days_result[weekdays].gt(0).sum(axis=1).astype(int)
    days_result['weekendOpened'] = days_result[weekend].gt(0).sum(axis=1).astype(int)
    days_result.drop(weekdays+weekend, axis=1, inplace=True)

    return days_result

## CÁLCULO DE RESULTADOS 4: TASAS DE OCUPACIÓN EN HORARIO DE APERTURA ##

def occupation_rates(rush_hours_df):
    rush_hours_df['monthlyOccupationRate'] = rush_hours_df.apply(       # Creamos el campo de monthlyOccupationRate utilizando la función auxiliar
        lambda row: calculate_monthly_occupation(row), axis=1)              
    global_occupation_df = pd.DataFrame(rush_hours_df['monthlyOccupationRate'].groupby('_id').mean())   # Hacemos una media de la tasa para el intervalo analizado
    global_occupation_df.columns = ['globalOccupationRate']
    
    return global_occupation_df

def is_in_interval(timestr, intervals):     # Función auxiliar para determinar si una hora se encuentra en un intervalo compuesto determinado
    time = datetime.strptime(timestr, '%H').time()
    if intervals is None:
        return False
    for start, end in intervals:
        if start <= end:
            if start <= time <= end:
                return True
        else:  # Para intervalos como (9:00, 2:00)
            if start <= time or time <= end:
                return True
    return False


def calculate_monthly_occupation(row):      # Función auxiliar que calcula para cada restaurante y mes la tasa de ocupación mensual en su horario de apertura
    rush_dict = dict(row['rush_hours_json'])
    occupation_rates = []

    for day, hours in rush_dict.items():
        if hours != []:
            for hour,rate in hours.items():
                if is_in_interval(hour,row[day]):
                    occupation_rates.append(rate)
    monthly_occupation = sum(occupation_rates) / len(occupation_rates) if occupation_rates else None
    return monthly_occupation


##  CÁLCULO DE RESULTADOS 5: REPETICIONES DEL CONCEPTO VINO  ##

def wine_reps(wine_rep_df):
    wine_month_df = wine_rep_df.groupby(['_id', 'intervalName'])['wine_present'].sum()  #Se crea el campo monthlyWineRepetitions
    wine_result_df = pd.DataFrame(wine_month_df.groupby('_id').sum())   #Se crea el campo totalWineRepetitions con el total de menciones para cada restaurante en el intervalo analizado
    wine_result_df.columns = ['totalWineRepetitions']
    wine_result_df['totalWineRepetitions'] = wine_result_df['totalWineRepetitions'].astype(int)

    return wine_result_df


##  CREACIÓN DE LA TABLA FINAL DE KPIS ##

def result_table(restaurants_df,avg_kpi,sum_kpi,open_days,occ_rates,wine_repetitions):
    
    header = restaurants_df[['_id','name','postal_code']]       # Extraemos los nombres de los restaurantes de nuestro subconjunto, ya que los añadiremos a la tabla final
    header.set_index('_id', inplace=True)

    # Todos los merge se harán de la forma 'left' para que los kpis que no se pudieron calcular por falta de información (en timetables, comments, etc.) queden como None
    result_df = pd.merge(header, avg_kpi, on='_id', how='left')
    result_df = pd.merge(result_df, sum_kpi, on='_id', how='left')
    result_df = pd.merge(result_df, open_days, on='_id', how='left')
    result_df = pd.merge(result_df, occ_rates, on='_id', how='left')
    result_df = pd.merge(result_df, wine_repetitions, on='_id', how='left')
    #column_types = {'_id': 'str','name': 'str','postal_code':'str','' 'int32', 'column2': 'float64', 'column3': 'category'}


    return result_df







